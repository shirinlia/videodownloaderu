YouTube Video Downloader
for UFAZ Study Project
by Abdurrahman Shirinli, Shahin Garayev, Turan Khidilov, Nijat Damirchiyev